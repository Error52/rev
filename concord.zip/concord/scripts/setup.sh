#!/usr/bin/env bash
# Concord setup for macOS and Linux.
#
#   ./scripts/setup.sh              # local use on this computer: http://localhost
#   ./scripts/setup.sh --lan        # other devices on your network: https://<LAN-IP>:8443
#   ./scripts/setup.sh --port 8080  # use another HTTP port (e.g. if 80 is busy or Docker is rootless)
#   ./scripts/setup.sh --force      # overwrite an existing .env
#
# Writes .env with fresh random secrets and the right network addresses for LiveKit/TURN.
# Compatible with the stock bash 3.2 on macOS (no bash-4 features, no GNU-only sed flags).
set -euo pipefail

cd "$(dirname "$0")/.."

MODE=local
HTTP_PORT=80
HTTPS_PORT=8443
FORCE=0
while [ $# -gt 0 ]; do
  case "$1" in
    --lan) MODE=lan ;;
    --port) HTTP_PORT="${2:?--port needs a value}"; shift ;;
    --https-port) HTTPS_PORT="${2:?--https-port needs a value}"; shift ;;
    --force) FORCE=1 ;;
    -h|--help) sed -n '2,10p' "$0"; exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done

bold() { printf '\033[1m%s\033[0m\n' "$*"; }
ok()   { printf '  \033[32m✔\033[0m %s\n' "$*"; }
warn() { printf '  \033[33m!\033[0m %s\n' "$*"; }
fail() { printf '  \033[31m✘\033[0m %s\n' "$*" >&2; exit 1; }

OS="$(uname -s)"
ARCH="$(uname -m)"
bold "Concord setup — $OS/$ARCH, mode: $MODE"

# ───────────── prerequisites ─────────────
command -v docker >/dev/null 2>&1 || {
  if [ "$OS" = "Darwin" ]; then fail "Docker not found. Install Docker Desktop (https://docs.docker.com/desktop/setup/install/mac-install/) or OrbStack/Colima."
  else fail "Docker not found. Install Docker Engine: https://docs.docker.com/engine/install/"; fi
}
docker compose version >/dev/null 2>&1 || fail "Docker Compose v2 not found ('docker compose'). Update Docker or install the compose plugin (docker-compose-plugin)."
ok "$(docker compose version | head -n1)"
if ! docker info >/dev/null 2>&1; then
  if [ "$OS" = "Darwin" ]; then warn "Docker daemon is not running — start Docker Desktop (or 'colima start') before 'make up'."
  else warn "Docker daemon not reachable. Start it (sudo systemctl start docker) and make sure your user is in the 'docker' group."; fi
else
  ok "Docker daemon is running"
fi

# Rootless Docker (Linux) cannot bind ports below 1024.
if [ "$OS" = "Linux" ] && [ "$HTTP_PORT" -lt 1024 ] && docker info 2>/dev/null | grep -qi rootless; then
  warn "Rootless Docker detected: port $HTTP_PORT is privileged — switching to 8080."
  HTTP_PORT=8080
fi

port_busy() {
  if command -v lsof >/dev/null 2>&1; then lsof -nP -iTCP:"$1" -sTCP:LISTEN >/dev/null 2>&1
  elif command -v ss >/dev/null 2>&1; then ss -ltn "( sport = :$1 )" 2>/dev/null | grep -q LISTEN
  else return 1; fi
}
for p in "$HTTP_PORT" 7881 3478; do
  if port_busy "$p"; then warn "Port $p is already in use. Free it or choose another (--port for HTTP)."; fi
done
if [ "$OS" = "Darwin" ] && [ "$HTTP_PORT" = "5000" ]; then warn "On macOS port 5000 is used by AirPlay Receiver."; fi

# ───────────── network address for media ─────────────
detect_ip() {
  local ip=""
  if [ "$OS" = "Darwin" ]; then
    # Interface of the default route (Wi-Fi is usually en0, Ethernet en1+, USB adapters vary).
    local iface
    iface="$(route -n get default 2>/dev/null | awk '/interface:/{print $2}')"
    [ -n "$iface" ] && ip="$(ipconfig getifaddr "$iface" 2>/dev/null || true)"
    [ -z "$ip" ] && ip="$(ipconfig getifaddr en0 2>/dev/null || ipconfig getifaddr en1 2>/dev/null || true)"
  else
    ip="$(ip -4 route get 1.1.1.1 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="src"){print $(i+1); exit}}')"
    [ -z "$ip" ] && ip="$(hostname -I 2>/dev/null | awk '{print $1}')"
  fi
  printf '%s' "$ip"
}

if [ "$MODE" = "lan" ]; then
  MEDIA_IP="$(detect_ip)"
  [ -n "$MEDIA_IP" ] || fail "Could not detect the LAN IP. Set LIVEKIT_NODE_IP / TURN_EXTERNAL_IP in .env manually."
  ok "LAN IP: $MEDIA_IP"
  APP_URL="https://$MEDIA_IP:$HTTPS_PORT"
  PUBLIC_HOST="$MEDIA_IP"
  COOKIE_SECURE=true
  PROFILES=https
else
  MEDIA_IP=127.0.0.1
  PUBLIC_HOST=localhost
  if [ "$HTTP_PORT" = "80" ]; then APP_URL="http://localhost"; else APP_URL="http://localhost:$HTTP_PORT"; fi
  COOKIE_SECURE=false
  PROFILES=""
fi

# ───────────── secrets ─────────────
secret() {
  if command -v openssl >/dev/null 2>&1; then openssl rand -hex "${1:-32}"
  else LC_ALL=C tr -dc 'a-f0-9' </dev/urandom | head -c "$(( ${1:-32} * 2 ))"; fi
}

if [ -f .env ] && [ "$FORCE" != "1" ]; then
  fail ".env already exists. Re-run with --force to regenerate it (secrets and data passwords will change)."
fi

# Fill the template line by line (portable: no 'sed -i' differences between BSD and GNU).
declare_val() { printf '%s=%s\n' "$1" "$2"; }
JWT="$(secret 32)"; PG="$(secret 16)"; S3="$(secret 20)"; LK="$(secret 32)"; TURN="$(secret 16)"
TMP="$(mktemp)"
while IFS= read -r line || [ -n "$line" ]; do
  key="${line%%=*}"
  case "$key" in
    APP_URL) declare_val APP_URL "$APP_URL" ;;
    HTTP_PORT) declare_val HTTP_PORT "$HTTP_PORT" ;;
    HTTPS_PORT) declare_val HTTPS_PORT "$HTTPS_PORT" ;;
    COOKIE_SECURE) declare_val COOKIE_SECURE "$COOKIE_SECURE" ;;
    COMPOSE_PROFILES) declare_val COMPOSE_PROFILES "$PROFILES" ;;
    POSTGRES_PASSWORD) declare_val POSTGRES_PASSWORD "$PG" ;;
    DATABASE_URL) declare_val DATABASE_URL "postgres://concord:$PG@localhost:5432/concord" ;;
    JWT_SECRET) declare_val JWT_SECRET "$JWT" ;;
    S3_SECRET_KEY) declare_val S3_SECRET_KEY "$S3" ;;
    LIVEKIT_API_SECRET) declare_val LIVEKIT_API_SECRET "$LK" ;;
    LIVEKIT_NODE_IP) declare_val LIVEKIT_NODE_IP "$MEDIA_IP" ;;
    TURN_SERVER) declare_val TURN_SERVER "turn:$PUBLIC_HOST:3478" ;;
    TURN_PUBLIC_HOST) declare_val TURN_PUBLIC_HOST "$PUBLIC_HOST" ;;
    TURN_EXTERNAL_IP) declare_val TURN_EXTERNAL_IP "$MEDIA_IP" ;;
    TURN_PASSWORD) declare_val TURN_PASSWORD "$TURN" ;;
    *) printf '%s\n' "$line" ;;
  esac
done < .env.example > "$TMP"
mv "$TMP" .env
chmod 600 .env
ok ".env written with fresh secrets"

bold "Next:"
if [ "$MODE" = "lan" ]; then
  echo "  make up            # or: docker compose up --build -d"
  echo "  open $APP_URL on any device in your network"
  echo "  The certificate is issued by Caddy's local CA: accept the browser warning once,"
  echo "  or trust it with:  make trust-cert"
else
  echo "  make up            # or: docker compose up --build -d"
  echo "  open $APP_URL"
fi
echo "  Demo users: alice@concord.local / demo12345 (also bob, carol, dave)"
if [ "$OS" = "Darwin" ]; then
  echo
  echo "  macOS: allow your browser in System Settings → Privacy & Security → Screen & System Audio Recording"
  echo "  (needed for screen sharing) and → Microphone / Camera."
fi
