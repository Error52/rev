import { useMemo, useState, type ChangeEvent, type FormEvent } from 'react';
import { api, ApiError, errorMessage } from '../api/client';
import { onAuthenticated } from '../state/actions';
import { navigate, type Route } from '../state/router';
import { toast } from '../state/ui';
import { ProfileCard } from '../components/profile/ProfileCard';
import { PRESET_THEMES } from '../utils/color';
import type { SelfUser, User } from '../types';

type AuthResponse = { user: SelfUser; accessToken: string } | { mfaRequired: true; ticket: string };

const BANNER_COLORS = ['#7c6cff', '#5865f2', '#3b82f6', '#14b8a6', '#22c55e', '#f59e0b', '#f97316', '#ef4444', '#ec4899', '#64748b'];

function Brand() {
  return (
    <div className="auth-brand">
      <img src="/favicon.svg" alt="" />
      Concord
    </div>
  );
}

function fieldErrors(err: unknown): Record<string, string> {
  if (err instanceof ApiError && Array.isArray(err.details)) {
    return Object.fromEntries((err.details as { path: string; message: string }[]).map((d) => [d.path, d.message]));
  }
  return {};
}

function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [ticket, setTicket] = useState<string | null>(null);
  const [code, setCode] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = ticket
        ? await api.post<AuthResponse>('/auth/mfa', { ticket, code })
        : await api.post<AuthResponse>('/auth/login', { email, password });
      if ('mfaRequired' in res) setTicket(res.ticket);
      else onAuthenticated(res.user, res.accessToken);
    } catch (err) {
      setError(errorMessage(err));
      if (err instanceof ApiError && err.code === 'MFA_EXPIRED') setTicket(null);
    } finally {
      setBusy(false);
    }
  };

  return (
    <form className="auth-card" onSubmit={submit}>
      <Brand />
      <h1>{ticket ? 'Двухфакторная проверка' : 'С возвращением!'}</h1>
      <p className="auth-sub">{ticket ? 'Введите 6-значный код из приложения-аутентификатора.' : 'Рады видеть вас снова.'}</p>
      <div className="auth-form">
        {ticket ? (
          <label className="field">
            <span className="field-label">Код</span>
            <input className="input" inputMode="numeric" autoComplete="one-time-code" maxLength={6} value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))} autoFocus />
          </label>
        ) : (
          <>
            <label className="field">
              <span className="field-label">Email</span>
              <input className="input" type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} required autoFocus />
            </label>
            <label className="field">
              <span className="field-label">Пароль</span>
              <input className="input" type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} required />
            </label>
            <button type="button" className="link-btn" style={{ alignSelf: 'flex-start', fontSize: '0.8125rem' }} onClick={() => navigate({ name: 'forgot' })}>
              Забыли пароль?
            </button>
          </>
        )}
        {error && <div className="field-error" role="alert">{error}</div>}
        <button className="btn btn-primary btn-block" disabled={busy}>
          {busy ? 'Входим…' : ticket ? 'Подтвердить' : 'Войти'}
        </button>
      </div>
      <p className="auth-alt">
        Нет аккаунта?{' '}
        <a href="/register" onClick={(e) => (e.preventDefault(), navigate({ name: 'register' }))}>
          Зарегистрироваться
        </a>
      </p>
    </form>
  );
}

function Register() {
  const [form, setForm] = useState({ username: '', displayName: '', email: '', password: '', confirm: '' });
  const [bannerColor, setBannerColor] = useState(BANNER_COLORS[0]!);
  const [preset, setPreset] = useState('default');
  const [avatar, setAvatar] = useState<File | null>(null);
  const [banner, setBanner] = useState<File | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof form) => (e: ChangeEvent<HTMLInputElement>) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const avatarUrl = useMemo(() => (avatar ? URL.createObjectURL(avatar) : null), [avatar]);
  const bannerUrl = useMemo(() => (banner ? URL.createObjectURL(banner) : null), [banner]);
  const preview: User = {
    id: 'preview',
    username: form.username || 'username',
    displayName: form.displayName || null,
    avatarUrl,
    bannerUrl,
    backgroundUrl: null,
    bannerColor,
    accentColor: bannerColor,
    bio: 'Так будет выглядеть ваш профиль.',
    theme: { preset, background: 'gradient' },
    status: 'online',
    customStatus: null,
    badges: [],
    createdAt: new Date().toISOString(),
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const local: Record<string, string> = {};
    if (form.password !== form.confirm) local.confirm = 'Пароли не совпадают';
    if (form.password.length < 8) local.password = 'Пароль — минимум 8 символов';
    for (const f of [avatar, banner]) if (f && f.size > 8 * 1024 * 1024) local.files = 'Изображение больше 8 МБ';
    setErrors(local);
    if (Object.keys(local).length) return;
    setBusy(true);
    try {
      const res = await api.post<{ user: SelfUser; accessToken: string }>('/auth/register', {
        username: form.username,
        email: form.email,
        password: form.password,
        displayName: form.displayName || undefined,
        bannerColor,
        accentColor: bannerColor,
        theme: { preset },
      });
      onAuthenticated(res.user, res.accessToken);
      // Images are uploaded after the account exists; failures don't block sign-up.
      try {
        if (avatar) await api.putFile('/users/me/avatar', avatar);
        if (banner) await api.putFile('/users/me/banner', banner);
      } catch (err) {
        toast(errorMessage(err, 'Не удалось загрузить изображение — попробуйте в настройках профиля'), 'error');
      }
    } catch (err) {
      const fe = fieldErrors(err);
      if (err instanceof ApiError && err.code === 'EMAIL_TAKEN') fe.email = err.message;
      else if (err instanceof ApiError && err.code === 'USERNAME_TAKEN') fe.username = err.message;
      else if (!Object.keys(fe).length) fe.form = errorMessage(err);
      setErrors(fe);
    } finally {
      setBusy(false);
    }
  };

  const err = (k: string) => errors[k] && <span className="field-error">{errors[k]}</span>;

  return (
    <form className="auth-card wide" onSubmit={submit}>
      <div>
        <Brand />
        <h1>Создать аккаунт</h1>
        <p className="auth-sub">Пара минут — и вы в сообществе.</p>
        <div className="auth-form">
          <div className="form-grid">
            <label className="field">
              <span className="field-label">Имя пользователя</span>
              <input className={`input${errors.username ? ' invalid' : ''}`} value={form.username} onChange={set('username')} autoComplete="username" required minLength={2} maxLength={32} pattern="[a-zA-Z0-9_.]+" title="Латиница, цифры, «_» и «.»" />
              {err('username')}
            </label>
            <label className="field">
              <span className="field-label">Отображаемое имя</span>
              <input className="input" value={form.displayName} onChange={set('displayName')} maxLength={32} />
            </label>
          </div>
          <label className="field">
            <span className="field-label">Email</span>
            <input className={`input${errors.email ? ' invalid' : ''}`} type="email" value={form.email} onChange={set('email')} autoComplete="email" required />
            {err('email')}
          </label>
          <div className="form-grid">
            <label className="field">
              <span className="field-label">Пароль</span>
              <input className={`input${errors.password ? ' invalid' : ''}`} type="password" value={form.password} onChange={set('password')} autoComplete="new-password" required />
              {err('password')}
            </label>
            <label className="field">
              <span className="field-label">Повторите пароль</span>
              <input className={`input${errors.confirm ? ' invalid' : ''}`} type="password" value={form.confirm} onChange={set('confirm')} autoComplete="new-password" required />
              {err('confirm')}
            </label>
          </div>
          <div className="form-grid">
            <label className="field">
              <span className="field-label">Аватар</span>
              <input className="input" type="file" accept="image/png,image/jpeg,image/gif,image/webp" onChange={(e) => setAvatar(e.target.files?.[0] ?? null)} />
            </label>
            <label className="field">
              <span className="field-label">Баннер</span>
              <input className="input" type="file" accept="image/png,image/jpeg,image/gif,image/webp" onChange={(e) => setBanner(e.target.files?.[0] ?? null)} />
            </label>
          </div>
          {err('files')}
          <div className="field">
            <span className="field-label">Цвет профиля</span>
            <div className="swatches">
              {BANNER_COLORS.map((c) => (
                <button key={c} type="button" className="swatch" style={{ background: c }} aria-pressed={c === bannerColor} aria-label={c} onClick={() => setBannerColor(c)} />
              ))}
            </div>
          </div>
          <div className="field">
            <span className="field-label">Тема профиля</span>
            <div className="theme-chips">
              {Object.entries(PRESET_THEMES).map(([key, t]) => (
                <button key={key} type="button" className="theme-chip" aria-pressed={preset === key} style={{ background: `linear-gradient(135deg, ${t.primary}, ${t.secondary})` }} onClick={() => setPreset(key)}>
                  {t.label}
                </button>
              ))}
            </div>
          </div>
          {err('form')}
          <button className="btn btn-primary btn-block" disabled={busy}>
            {busy ? 'Создаём…' : 'Продолжить'}
          </button>
        </div>
        <p className="auth-alt">
          Уже есть аккаунт?{' '}
          <a href="/login" onClick={(e) => (e.preventDefault(), navigate({ name: 'login' }))}>
            Войти
          </a>
        </p>
      </div>
      <div className="auth-preview">
        <span className="field-label">Предпросмотр</span>
        <ProfileCard user={preview} />
      </div>
    </form>
  );
}

function Forgot() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      await api.post('/auth/password/forgot', { email });
      setSent(true);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };
  return (
    <form className="auth-card" onSubmit={submit}>
      <Brand />
      <h1>Восстановление пароля</h1>
      <p className="auth-sub">{sent ? 'Если такой аккаунт существует, мы отправили письмо со ссылкой. Ссылка действует 1 час.' : 'Укажите email — пришлём ссылку для сброса.'}</p>
      {!sent && (
        <div className="auth-form">
          <label className="field">
            <span className="field-label">Email</span>
            <input className="input" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required autoFocus />
          </label>
          {error && <div className="field-error">{error}</div>}
          <button className="btn btn-primary btn-block" disabled={busy}>
            Отправить ссылку
          </button>
        </div>
      )}
      <p className="auth-alt">
        <a href="/login" onClick={(e) => (e.preventDefault(), navigate({ name: 'login' }))}>
          ← Вернуться ко входу
        </a>
      </p>
    </form>
  );
}

function Reset({ token }: { token: string }) {
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (password !== confirm) return setError('Пароли не совпадают');
    setBusy(true);
    try {
      await api.post('/auth/password/reset', { token, password });
      toast('Пароль изменён. Войдите с новым паролем.', 'success');
      navigate({ name: 'login' }, true);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };
  return (
    <form className="auth-card" onSubmit={submit}>
      <Brand />
      <h1>Новый пароль</h1>
      <p className="auth-sub">После смены пароля все остальные сеансы будут завершены.</p>
      <div className="auth-form">
        <label className="field">
          <span className="field-label">Новый пароль</span>
          <input className="input" type="password" autoComplete="new-password" minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} required />
        </label>
        <label className="field">
          <span className="field-label">Повторите пароль</span>
          <input className="input" type="password" autoComplete="new-password" value={confirm} onChange={(e) => setConfirm(e.target.value)} required />
        </label>
        {error && <div className="field-error">{error}</div>}
        <button className="btn btn-primary btn-block" disabled={busy || !token}>
          Сохранить
        </button>
      </div>
    </form>
  );
}

export function AuthPage({ route }: { route: Route }) {
  return (
    <div className="auth-shell">
      {route.name === 'register' ? <Register /> : route.name === 'forgot' ? <Forgot /> : route.name === 'reset' ? <Reset token={route.token} /> : <Login />}
    </div>
  );
}
