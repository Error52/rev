import { useRef, useState } from 'react';
import { LuExpand, LuPictureInPicture2, LuX } from 'react-icons/lu';
import { useVoice } from '../../webrtc/voiceEngine';
import { useRoute, navigate } from '../../state/router';
import { stageStore, useStage } from './stageState';
import { togglePip, VideoTile } from './VideoTile';

/**
 * Floating in-app mini-player: draggable by its top bar, resizable from the corner (CSS resize),
 * and visible on every page while a video/stream is focused and you're away from the stage.
 */
export function MiniPlayer() {
  const focus = useStage((s) => s.focus);
  const popped = useStage((s) => s.popped);
  const p = useVoice((v) => (focus ? v.participants[focus.identity] : undefined));
  const voiceChannel = useVoice((v) => ({ channelId: v.channelId, serverId: v.serverId, isDm: v.isDm }));
  const route = useRoute();
  const [pos, setPos] = useState({ x: window.innerWidth - 400, y: window.innerHeight - 280 });
  const drag = useRef<{ dx: number; dy: number } | null>(null);
  const boxRef = useRef<HTMLDivElement>(null);

  const onStage =
    (route.name === 'channel' && route.channelId === voiceChannel.channelId) || (route.name === 'dm' && route.channelId === voiceChannel.channelId);
  if (!focus || !p || (onStage && !popped)) return null;

  const back = () => {
    stageStore.set({ popped: false });
    if (!voiceChannel.channelId) return;
    if (voiceChannel.isDm) navigate({ name: 'dm', channelId: voiceChannel.channelId });
    else if (voiceChannel.serverId) navigate({ name: 'channel', serverId: voiceChannel.serverId, channelId: voiceChannel.channelId });
  };

  return (
    <div
      ref={boxRef}
      className="mini-player"
      style={{ left: Math.max(8, Math.min(pos.x, window.innerWidth - 228)), top: Math.max(8, Math.min(pos.y, window.innerHeight - 140)), width: 380, height: 214 }}
    >
      <div
        className="mini-player-bar"
        onPointerDown={(e) => {
          if ((e.target as HTMLElement).closest('button')) return;
          drag.current = { dx: e.clientX - pos.x, dy: e.clientY - pos.y };
          (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
        }}
        onPointerMove={(e) => drag.current && setPos({ x: e.clientX - drag.current.dx, y: e.clientY - drag.current.dy })}
        onPointerUp={() => (drag.current = null)}
      >
        <span className="grow ellipsis">{p.name}</span>
        <button onClick={() => void togglePip(boxRef.current?.querySelector('video') ?? null)} aria-label="Картинка в картинке">
          <LuPictureInPicture2 />
        </button>
        <button onClick={back} aria-label="Вернуться к звонку">
          <LuExpand />
        </button>
        <button onClick={() => stageStore.set({ focus: null, popped: false })} aria-label="Закрыть">
          <LuX />
        </button>
      </div>
      <VideoTile p={p} source={focus.source} serverId={voiceChannel.serverId} compact />
    </div>
  );
}
