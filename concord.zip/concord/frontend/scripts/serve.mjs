// Development server without Docker/nginx: serves dist/ (SPA fallback) and proxies
// /api (HTTP + WebSocket gateway) to the backend and /livekit to the SFU.
//   BACKEND=http://localhost:4000 LIVEKIT=http://localhost:7880 PORT=5173 node scripts/serve.mjs
import http from 'node:http';
import net from 'node:net';
import { createReadStream } from 'node:fs';
import { stat } from 'node:fs/promises';
import path from 'node:path';

const PORT = Number(process.env.PORT ?? 5173);
const BACKEND = new URL(process.env.BACKEND ?? 'http://localhost:4000');
const LIVEKIT = new URL(process.env.LIVEKIT ?? 'http://localhost:7880');
const ROOT = path.resolve('dist');
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.map': 'application/json', '.woff2': 'font/woff2' };

function target(url) {
  if (url.startsWith('/api/') || url === '/api') return { host: BACKEND, path: url };
  if (url.startsWith('/livekit')) return { host: LIVEKIT, path: url.replace(/^\/livekit/, '') || '/' };
  return null;
}

const server = http.createServer(async (req, res) => {
  const t = target(req.url ?? '/');
  if (t) {
    const p = http.request(
      { hostname: t.host.hostname, port: t.host.port, path: t.path, method: req.method, headers: { ...req.headers, 'x-forwarded-for': req.socket.remoteAddress ?? '' } },
      (r) => {
        res.writeHead(r.statusCode ?? 502, r.headers);
        r.pipe(res);
      },
    );
    p.on('error', () => {
      res.writeHead(502).end();
    });
    req.pipe(p);
    return;
  }
  const clean = decodeURIComponent((req.url ?? '/').split('?')[0]);
  let file = path.join(ROOT, path.normalize(clean));
  if (!file.startsWith(ROOT)) return res.writeHead(403).end();
  try {
    if (!(await stat(file)).isFile()) throw new Error('dir');
  } catch {
    file = path.join(ROOT, 'index.html');
  }
  res.writeHead(200, { 'Content-Type': TYPES[path.extname(file)] ?? 'application/octet-stream' });
  createReadStream(file).pipe(res);
});

// WebSocket upgrades: raw TCP tunnel to the upstream.
server.on('upgrade', (req, socket, head) => {
  const t = target(req.url ?? '/');
  if (!t) return socket.destroy();
  const up = net.connect(Number(t.host.port), t.host.hostname, () => {
    const headers = Object.entries(req.headers).map(([k, v]) => `${k}: ${v}`).join('\r\n');
    up.write(`${req.method} ${t.path} HTTP/1.1\r\n${headers}\r\n\r\n`);
    up.write(head);
    socket.pipe(up).pipe(socket);
  });
  up.on('error', () => socket.destroy());
  socket.on('error', () => up.destroy());
});

server.listen(PORT, () => console.log(`Concord dev server on http://localhost:${PORT} → ${BACKEND.href}`));
