import net from 'node:net';
import tls from 'node:tls';
import { randomUUID } from 'node:crypto';
import { config } from '../config.js';
import { log } from '../logger.js';

/**
 * Minimal SMTP client (EHLO, optional STARTTLS, AUTH PLAIN). Enough for Mailpit in development
 * and for typical transactional relays in production.
 */
type Sock = net.Socket | tls.TLSSocket;

class SmtpSession {
  private buffer = '';
  private waiters: Array<(line: string) => void> = [];

  constructor(private sock: Sock) {
    this.attach(sock);
  }

  private attach(sock: Sock): void {
    sock.setEncoding('utf8');
    sock.on('data', (chunk: string) => {
      this.buffer += chunk;
      let idx: number;
      // A reply is complete when a line has "NNN " (space, not dash) after the code.
      while ((idx = this.buffer.search(/^\d{3} .*\r\n/m)) >= 0) {
        const end = this.buffer.indexOf('\r\n', idx) + 2;
        const reply = this.buffer.slice(0, end);
        this.buffer = this.buffer.slice(end);
        this.waiters.shift()?.(reply);
      }
    });
  }

  read(): Promise<string> {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('SMTP timeout')), 15_000);
      this.waiters.push((line) => {
        clearTimeout(timer);
        resolve(line);
      });
    });
  }

  async cmd(line: string, expect: number): Promise<string> {
    this.sock.write(line + '\r\n');
    const reply = await this.read();
    if (!reply.startsWith(String(expect))) throw new Error(`SMTP unexpected reply to ${line.split(' ')[0]}: ${reply.slice(0, 3)}`);
    return reply;
  }

  async upgrade(host: string): Promise<void> {
    this.sock.removeAllListeners('data');
    this.sock = await new Promise<tls.TLSSocket>((resolve, reject) => {
      const s = tls.connect({ socket: this.sock as net.Socket, servername: host }, () => resolve(s));
      s.once('error', reject);
    });
    this.attach(this.sock);
  }

  end(): void {
    this.sock.end();
  }
}

export interface Mail {
  to: string;
  subject: string;
  text: string;
  html: string;
}

function encodeHeader(value: string): string {
  return /^[\x20-\x7e]*$/.test(value) ? value : `=?UTF-8?B?${Buffer.from(value).toString('base64')}?=`;
}

export async function sendMail(mail: Mail): Promise<void> {
  if (!config.SMTP_HOST) {
    log.warn('SMTP_HOST not configured; email not sent', { subject: mail.subject });
    return;
  }
  const host = config.SMTP_HOST;
  const sock = net.connect({ host, port: config.SMTP_PORT });
  await new Promise<void>((resolve, reject) => {
    sock.once('connect', resolve);
    sock.once('error', reject);
  });
  const s = new SmtpSession(sock);
  try {
    await s.read(); // greeting
    await s.cmd(`EHLO concord.local`, 250);
    if (config.SMTP_STARTTLS) {
      await s.cmd('STARTTLS', 220);
      await s.upgrade(host);
      await s.cmd(`EHLO concord.local`, 250);
    }
    if (config.SMTP_USER && config.SMTP_PASSWORD) {
      const token = Buffer.from(`\0${config.SMTP_USER}\0${config.SMTP_PASSWORD}`).toString('base64');
      await s.cmd(`AUTH PLAIN ${token}`, 235);
    }
    const from = /<([^>]+)>/.exec(config.MAIL_FROM)?.[1] ?? config.MAIL_FROM;
    await s.cmd(`MAIL FROM:<${from}>`, 250);
    await s.cmd(`RCPT TO:<${mail.to}>`, 250);
    await s.cmd('DATA', 354);
    const boundary = `b_${randomUUID()}`;
    const body = [
      `From: ${config.MAIL_FROM}`,
      `To: <${mail.to}>`,
      `Subject: ${encodeHeader(mail.subject)}`,
      `Date: ${new Date().toUTCString()}`,
      `Message-ID: <${randomUUID()}@concord.local>`,
      'MIME-Version: 1.0',
      `Content-Type: multipart/alternative; boundary="${boundary}"`,
      '',
      `--${boundary}`,
      'Content-Type: text/plain; charset=utf-8',
      'Content-Transfer-Encoding: base64',
      '',
      Buffer.from(mail.text).toString('base64').replace(/.{76}/g, '$&\r\n'),
      `--${boundary}`,
      'Content-Type: text/html; charset=utf-8',
      'Content-Transfer-Encoding: base64',
      '',
      Buffer.from(mail.html).toString('base64').replace(/.{76}/g, '$&\r\n'),
      `--${boundary}--`,
      '.',
    ].join('\r\n');
    await s.cmd(body, 250);
    await s.cmd('QUIT', 221).catch(() => undefined);
  } finally {
    s.end();
  }
}
