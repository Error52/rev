import { createHash, randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';
import { config } from '../config.js';
import { execute, query, queryOne, tx, type Queryable } from '../db/pool.js';
import { Errors, AppError } from '../http/errors.js';
import { signJwt, verifyJwt } from '../auth/jwt.js';
import { getDummyHash, hashPassword, verifyPassword } from '../auth/password.js';
import { generateTotpSecret, otpauthUrl, verifyTotp } from '../auth/totp.js';
import * as users from '../repositories/userRepo.js';
import { redis } from '../redis.js';
import { revokedSessionKey } from '../middleware/auth.js';
import { control } from '../websocket/bus.js';
import { sendMail } from './mailer.js';
import { log } from '../logger.js';
import type { SelfUser, ProfileTheme } from '../models/dto.js';

const sha256 = (s: string): string => createHash('sha256').update(s).digest('hex');
/** Refresh reuse within this window is treated as a benign race between tabs, not theft. */
const ROTATION_GRACE_MS = 10_000;

export interface SessionTokens {
  accessToken: string;
  /** Cookie value: "<sessionId>.<secret>". */
  refreshToken: string;
  refreshMaxAgeSec: number;
}

export interface ClientInfo {
  ip: string;
  userAgent: string | undefined;
}

function issueAccess(userId: string, sessionId: string): string {
  return signJwt({ sub: userId, sid: sessionId, typ: 'access' }, config.JWT_SECRET, config.ACCESS_TOKEN_TTL_SEC);
}

async function createSession(userId: string, client: ClientInfo, familyId: string = randomUUID(), db?: Queryable): Promise<SessionTokens> {
  const secret = randomBytes(32).toString('base64url');
  const maxAge = config.REFRESH_TOKEN_TTL_DAYS * 86_400;
  const row = await queryOne<{ id: string }>(
    `INSERT INTO sessions (user_id, family_id, refresh_token_hash, user_agent, ip, expires_at)
     VALUES ($1, $2, $3, $4, $5, now() + make_interval(secs => $6)) RETURNING id`,
    [userId, familyId, sha256(secret), client.userAgent?.slice(0, 255) ?? null, client.ip, maxAge],
    db,
  );
  const sessionId = row!.id;
  return { accessToken: issueAccess(userId, sessionId), refreshToken: `${sessionId}.${secret}`, refreshMaxAgeSec: maxAge };
}

async function revokeSessions(ids: string[]): Promise<void> {
  if (ids.length === 0) return;
  await execute(`UPDATE sessions SET revoked_at = now() WHERE id = ANY($1::uuid[]) AND revoked_at IS NULL`, [ids]);
  const ttl = config.ACCESS_TOKEN_TTL_SEC + 60;
  const pipe = redis.pipeline();
  for (const id of ids) pipe.set(revokedSessionKey(id), '1', 'EX', ttl);
  await pipe.exec();
  await control({ kind: 'revoke', sessionIds: ids });
}

export interface RegisterInput {
  username: string;
  email: string;
  password: string;
  displayName?: string;
  bannerColor?: string;
  accentColor?: string;
  theme?: ProfileTheme;
}

export async function register(input: RegisterInput, client: ClientInfo): Promise<{ user: SelfUser; tokens: SessionTokens }> {
  if (await users.findByEmail(input.email)) throw Errors.conflict('EMAIL_TAKEN', 'Этот email уже зарегистрирован');
  if (await users.findByUsername(input.username)) throw Errors.conflict('USERNAME_TAKEN', 'Это имя пользователя уже занято');
  const passwordHash = await hashPassword(input.password);

  const { userId, tokens } = await tx(async (db) => {
    const u = await queryOne<{ id: string }>(
      `INSERT INTO users (email, username, display_name, password_hash) VALUES ($1, $2, $3, $4) RETURNING id`,
      [input.email.trim(), input.username, input.displayName?.trim() || null, passwordHash],
      db,
    );
    await execute(
      `INSERT INTO profiles (user_id, banner_color, accent_color, theme) VALUES ($1, coalesce($2, '#5b5bd6'), coalesce($3, '#7c6cff'), coalesce($4::jsonb, '{"preset":"default"}'::jsonb))`,
      [u!.id, input.bannerColor ?? null, input.accentColor ?? null, input.theme ? JSON.stringify(input.theme) : null],
      db,
    );
    return { userId: u!.id, tokens: await createSession(u!.id, client, undefined, db) };
  });
  const row = await users.findById(userId);
  return { user: await users.toSelf(row!), tokens };
}

export type LoginResult = { kind: 'ok'; user: SelfUser; tokens: SessionTokens } | { kind: 'mfa'; ticket: string };

export async function login(email: string, password: string, client: ClientInfo): Promise<LoginResult> {
  const row = await users.findByEmail(email);
  // Always run the KDF so response time does not leak account existence.
  const ok = await verifyPassword(password, row?.password_hash ?? (await getDummyHash()));
  if (!row || !ok) throw new AppError(401, 'INVALID_CREDENTIALS', 'Неверный email или пароль');
  if (row.totp_enabled) {
    return { kind: 'mfa', ticket: signJwt({ sub: row.id, typ: 'mfa' }, config.JWT_SECRET, 300) };
  }
  return { kind: 'ok', user: await users.toSelf(row), tokens: await createSession(row.id, client) };
}

export async function completeMfa(ticket: string, code: string, client: ClientInfo): Promise<{ user: SelfUser; tokens: SessionTokens }> {
  const claims = verifyJwt<{ sub: string; typ: string }>(ticket, config.JWT_SECRET);
  if (!claims || claims.typ !== 'mfa') throw new AppError(401, 'MFA_EXPIRED', 'Сессия входа истекла, войдите заново');
  const row = await users.findById(claims.sub);
  if (!row?.totp_enabled || !row.totp_secret || !verifyTotp(row.totp_secret, code)) {
    throw new AppError(401, 'INVALID_CODE', 'Неверный код подтверждения');
  }
  // Prevent replay of the same code within its validity window.
  const replayKey = `totp-used:${row.id}:${code}`;
  if ((await redis.set(replayKey, '1', 'EX', 90, 'NX')) !== 'OK') throw new AppError(401, 'INVALID_CODE', 'Код уже использован');
  return { user: await users.toSelf(row), tokens: await createSession(row.id, client) };
}

interface SessionRow {
  id: string;
  user_id: string;
  family_id: string;
  refresh_token_hash: string;
  expires_at: Date;
  revoked_at: Date | null;
  rotated_at: Date | null;
}

/**
 * Refresh-token rotation with reuse detection: each refresh token is single-use.
 * Presenting an already-rotated token (outside a short grace window) revokes the whole family,
 * because it means the token was copied.
 */
export async function refresh(cookieValue: string | undefined, client: ClientInfo): Promise<SessionTokens> {
  const invalid = new AppError(401, 'SESSION_EXPIRED', 'Сессия истекла, войдите снова');
  if (!cookieValue) throw invalid;
  const [sessionId, secret] = cookieValue.split('.');
  if (!sessionId || !secret || !/^[0-9a-f-]{36}$/.test(sessionId)) throw invalid;

  return tx(async (db) => {
    const s = await queryOne<SessionRow>(`SELECT * FROM sessions WHERE id = $1 FOR UPDATE`, [sessionId], db);
    if (!s) throw invalid;
    const a = Buffer.from(sha256(secret));
    const b = Buffer.from(s.refresh_token_hash);
    if (a.length !== b.length || !timingSafeEqual(a, b)) throw invalid;
    if (s.rotated_at) {
      if (Date.now() - s.rotated_at.getTime() > ROTATION_GRACE_MS) {
        log.warn('refresh token reuse detected; revoking family', { userId: s.user_id });
        const family = await query<{ id: string }>(`SELECT id FROM sessions WHERE family_id = $1`, [s.family_id], db);
        queueMicrotask(() => void revokeSessions(family.map((f) => f.id)));
      }
      throw invalid;
    }
    if (s.revoked_at || s.expires_at.getTime() < Date.now()) throw invalid;
    const next = await createSession(s.user_id, client, s.family_id, db);
    const nextId = next.refreshToken.split('.')[0];
    await execute(`UPDATE sessions SET rotated_at = now(), revoked_at = now(), replaced_by = $2 WHERE id = $1`, [s.id, nextId], db);
    return next;
  });
}

export async function logout(sessionId: string): Promise<void> {
  await revokeSessions([sessionId]);
}

export async function logoutByCookie(cookieValue: string | undefined): Promise<void> {
  const sessionId = cookieValue?.split('.')[0];
  if (sessionId && /^[0-9a-f-]{36}$/.test(sessionId)) await revokeSessions([sessionId]);
}

export async function listSessions(userId: string, currentSessionId: string) {
  const rows = await query<{ id: string; user_agent: string | null; ip: string | null; created_at: Date; last_used_at: Date }>(
    `SELECT id, user_agent, ip, created_at, last_used_at FROM sessions
      WHERE user_id = $1 AND revoked_at IS NULL AND expires_at > now() ORDER BY created_at DESC`,
    [userId],
  );
  return rows.map((r) => ({
    id: r.id,
    userAgent: r.user_agent,
    ip: r.ip,
    createdAt: r.created_at.toISOString(),
    current: r.id === currentSessionId,
  }));
}

export async function revokeSession(userId: string, sessionId: string): Promise<void> {
  const owned = await queryOne(`SELECT 1 FROM sessions WHERE id = $1 AND user_id = $2`, [sessionId, userId]);
  if (!owned) throw Errors.notFound('Сессия');
  await revokeSessions([sessionId]);
}

export async function changePassword(userId: string, sessionId: string, current: string, next: string): Promise<void> {
  const row = await users.findById(userId);
  if (!row || !(await verifyPassword(current, row.password_hash))) throw new AppError(400, 'INVALID_PASSWORD', 'Текущий пароль неверен');
  await execute(`UPDATE users SET password_hash = $2, updated_at = now() WHERE id = $1`, [userId, await hashPassword(next)]);
  const others = await query<{ id: string }>(`SELECT id FROM sessions WHERE user_id = $1 AND id <> $2 AND revoked_at IS NULL`, [userId, sessionId]);
  await revokeSessions(others.map((o) => o.id));
}

export async function requestPasswordReset(email: string): Promise<void> {
  const row = await users.findByEmail(email);
  if (!row) return; // do not reveal whether the account exists
  const token = randomBytes(32).toString('base64url');
  await execute(`INSERT INTO password_resets (user_id, token_hash, expires_at) VALUES ($1, $2, now() + interval '1 hour')`, [
    row.id,
    sha256(token),
  ]);
  const link = `${config.APP_URL}/reset-password?token=${token}`;
  try {
    await sendMail({
      to: row.email,
      subject: 'Concord — восстановление пароля',
      text: `Чтобы задать новый пароль, откройте ссылку (действует 1 час):\n${link}\n\nЕсли вы не запрашивали сброс, просто проигнорируйте это письмо.`,
      html: `<p>Чтобы задать новый пароль, нажмите на ссылку (действует 1 час):</p><p><a href="${link}">Сбросить пароль</a></p><p>Если вы не запрашивали сброс, проигнорируйте это письмо.</p>`,
    });
  } catch (err) {
    log.error('failed to send reset email', { err });
  }
}

export async function confirmPasswordReset(token: string, password: string): Promise<void> {
  const row = await queryOne<{ id: string; user_id: string }>(
    `SELECT id, user_id FROM password_resets WHERE token_hash = $1 AND used_at IS NULL AND expires_at > now()`,
    [sha256(token)],
  );
  if (!row) throw new AppError(400, 'RESET_INVALID', 'Ссылка недействительна или устарела');
  await tx(async (db) => {
    await execute(`UPDATE password_resets SET used_at = now() WHERE id = $1`, [row.id], db);
    await execute(`UPDATE users SET password_hash = $2, updated_at = now() WHERE id = $1`, [row.user_id, await hashPassword(password)], db);
  });
  const sessions = await query<{ id: string }>(`SELECT id FROM sessions WHERE user_id = $1 AND revoked_at IS NULL`, [row.user_id]);
  await revokeSessions(sessions.map((s) => s.id));
}

// ─────────────── TOTP 2FA ───────────────

export async function beginTotpSetup(userId: string): Promise<{ secret: string; otpauthUrl: string }> {
  const row = await users.findById(userId);
  if (!row) throw Errors.notFound('Пользователь');
  if (row.totp_enabled) throw Errors.conflict('TOTP_ENABLED', 'Двухфакторная аутентификация уже включена');
  const secret = generateTotpSecret();
  await redis.set(`totp-setup:${userId}`, secret, 'EX', 600);
  return { secret, otpauthUrl: otpauthUrl(secret, row.email) };
}

export async function enableTotp(userId: string, code: string): Promise<void> {
  const secret = await redis.get(`totp-setup:${userId}`);
  if (!secret) throw new AppError(400, 'TOTP_SETUP_EXPIRED', 'Начните настройку заново');
  if (!verifyTotp(secret, code)) throw new AppError(400, 'INVALID_CODE', 'Неверный код подтверждения');
  await execute(`UPDATE users SET totp_secret = $2, totp_enabled = true, updated_at = now() WHERE id = $1`, [userId, secret]);
  await redis.del(`totp-setup:${userId}`);
}

export async function disableTotp(userId: string, password: string, code: string): Promise<void> {
  const row = await users.findById(userId);
  if (!row?.totp_enabled || !row.totp_secret) throw new AppError(400, 'TOTP_DISABLED', '2FA не включена');
  if (!(await verifyPassword(password, row.password_hash))) throw new AppError(400, 'INVALID_PASSWORD', 'Неверный пароль');
  if (!verifyTotp(row.totp_secret, code)) throw new AppError(400, 'INVALID_CODE', 'Неверный код подтверждения');
  await execute(`UPDATE users SET totp_secret = NULL, totp_enabled = false, updated_at = now() WHERE id = $1`, [userId]);
}

export async function touchSession(sessionId: string): Promise<void> {
  await execute(`UPDATE sessions SET last_used_at = now() WHERE id = $1`, [sessionId]);
}
