#!/usr/bin/env bash
# One-command install on a fresh Linux VPS (Ubuntu 22.04/24.04, Debian 12; other distros with Docker preinstalled).
#
#   sudo ./scripts/install-server.sh chat.example.com you@example.com
#   sudo ./scripts/install-server.sh                       # no domain → https://<ip>.sslip.io
#
# What it does: installs Docker if missing, opens the firewall ports (ufw/firewalld if active),
# writes .env for public use (Let's Encrypt HTTPS, public IP for media/TURN), builds and starts everything.
set -euo pipefail
cd "$(dirname "$0")/.."

DOMAIN="${1:-}"
EMAIL="${2:-}"

[ "$(id -u)" = "0" ] || { echo "Run with sudo: sudo $0 $*" >&2; exit 1; }
[ "$(uname -s)" = "Linux" ] || { echo "This script is for a Linux server." >&2; exit 1; }

echo "==> Docker"
if ! command -v docker >/dev/null 2>&1; then
  command -v curl >/dev/null 2>&1 || { apt-get update -y && apt-get install -y curl; }
  curl -fsSL https://get.docker.com | sh
fi
systemctl enable --now docker >/dev/null 2>&1 || true
docker compose version >/dev/null 2>&1 || { apt-get update -y && apt-get install -y docker-compose-plugin; }
docker compose version

echo "==> Firewall"
PORTS_TCP="80 443 7881 3478"
PORTS_UDP="443 7882 3478"
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
  ufw allow OpenSSH >/dev/null || true
  for p in $PORTS_TCP; do ufw allow "$p/tcp" >/dev/null; done
  for p in $PORTS_UDP; do ufw allow "$p/udp" >/dev/null; done
  ufw allow 49160:49200/udp >/dev/null
  echo "ufw: ports opened"
elif command -v firewall-cmd >/dev/null 2>&1 && firewall-cmd --state >/dev/null 2>&1; then
  for p in $PORTS_TCP; do firewall-cmd --permanent --add-port="$p/tcp" >/dev/null; done
  for p in $PORTS_UDP; do firewall-cmd --permanent --add-port="$p/udp" >/dev/null; done
  firewall-cmd --permanent --add-port=49160-49200/udp >/dev/null
  firewall-cmd --reload >/dev/null
  echo "firewalld: ports opened"
else
  echo "No active ufw/firewalld — nothing to change on this machine."
fi
echo "Cloud providers (AWS, Hetzner, Oracle, Yandex Cloud…): also allow these ports in the provider's firewall / security group:"
echo "  TCP 80, 443, 7881, 3478 · UDP 443, 7882, 3478, 49160-49200"

echo "==> Configuration"
ARGS="--server --force"
[ -n "$DOMAIN" ] && ARGS="$ARGS --domain $DOMAIN"
[ -n "$EMAIL" ] && ARGS="$ARGS --email $EMAIL"
if [ -f .env ]; then
  echo ".env exists — keeping it (delete it to regenerate secrets)."
else
  # shellcheck disable=SC2086
  ./scripts/setup.sh $ARGS
fi

echo "==> Build and start"
docker compose up --build -d
URL="$(grep -E '^APP_URL=' .env | cut -d= -f2-)"

echo "==> Waiting for HTTPS ($URL)"
for _ in $(seq 1 60); do
  if curl -fsS --max-time 5 "$URL/api/health" >/dev/null 2>&1; then
    echo
    echo "  Concord is running: $URL"
    echo "  Register the first account, create a server and send friends an invite link."
    exit 0
  fi
  sleep 5
done
echo "Not reachable yet. Check: docker compose logs caddy-public backend  (DNS A record and ports 80/443 must be correct)." >&2
exit 1
