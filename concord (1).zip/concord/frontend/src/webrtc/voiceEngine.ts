import {
  AudioPresets,
  ConnectionQuality,
  DisconnectReason,
  LocalTrackPublication,
  Room,
  RoomEvent,
  ScreenSharePresets,
  Track,
  VideoPresets,
  type Participant,
  type RemoteParticipant,
  type RemoteTrack,
  type RemoteTrackPublication,
} from 'livekit-client';
import { api, errorMessage } from '../api/client';
import { createStore, useStoreSelector } from '../state/store';
import { settingsStore, type Settings } from '../state/settings';
import { toast } from '../state/ui';
import { gateway } from '../state/actions';
import { getState } from '../state/app';
import { createMeter, VoiceActivityDetector } from './audioMeter';
import { mediaErrorMessage } from './devices';
import { StatsSampler, type ConnectionStats } from './stats';
import { joinSound, leaveSound, muteSound, unmuteSound } from '../utils/notify';
import { log } from '../utils/log';
import { IS_LINUX, IS_MAC } from '../utils/platform';

/**
 * Voice/video engine on top of the LiveKit SFU.
 *
 * Microphone path (all real audio, nothing simulated):
 *   getUserMedia(constraints) → MediaStreamSource → input gain → gate gain → MediaStreamDestination → published track
 *                                                      └→ AudioWorklet level meter → VAD / speaking indicator
 * Voice Activity and Push-to-Talk both drive the gate gain, so the far end only receives audio while the
 * gate is open. User mute uses LiveKit's track mute (signalled to others); server mute is enforced by the SFU.
 */

export type VoiceStatus = 'idle' | 'connecting' | 'connected' | 'reconnecting';

export interface ParticipantView {
  identity: string;
  name: string;
  avatarUrl: string | null;
  isLocal: boolean;
  speaking: boolean;
  micMuted: boolean;
  hasCamera: boolean;
  hasScreen: boolean;
  hasScreenAudio: boolean;
  watchingScreen: boolean;
  quality: 'excellent' | 'good' | 'poor' | 'lost' | 'unknown';
}

export interface VoiceSnapshot {
  status: VoiceStatus;
  channelId: string | null;
  serverId: string | null;
  isDm: boolean;
  selfMute: boolean;
  selfDeaf: boolean;
  serverMute: boolean;
  serverDeaf: boolean;
  camera: boolean;
  screen: boolean;
  /** null = not sharing; true = system/tab audio is being sent; false = source/browser gave no audio */
  screenAudio: boolean | null;
  pttHeld: boolean;
  gateOpen: boolean;
  localSpeaking: boolean;
  participants: Record<string, ParticipantView>;
  stats: ConnectionStats | null;
  audioBlocked: boolean;
  joinedAt: number | null;
  /** bumps whenever tracks change so video tiles re-attach */
  version: number;
}

/** Stream audio is music/game sound: no voice DTX/RED tricks, high bitrate. */
const STREAM_AUDIO_PUBLISH = { audioPreset: AudioPresets.musicHighQualityStereo, dtx: false, red: false };

const initial: VoiceSnapshot = {
  status: 'idle',
  channelId: null,
  serverId: null,
  isDm: false,
  selfMute: false,
  selfDeaf: false,
  serverMute: false,
  serverDeaf: false,
  camera: false,
  screen: false,
  screenAudio: null,
  pttHeld: false,
  gateOpen: false,
  localSpeaking: false,
  participants: {},
  stats: null,
  audioBlocked: false,
  joinedAt: null,
  version: 0,
};

export const voiceStore = createStore<VoiceSnapshot>(initial);
export function useVoice<T>(selector: (s: VoiceSnapshot) => T): T {
  return useStoreSelector(voiceStore, selector);
}

/** Level listeners get every meter reading (≈100/s) without going through React state. */
type LevelListener = (db: number, threshold: number) => void;

const QUALITY: Record<string, ParticipantView['quality']> = {
  [ConnectionQuality.Excellent]: 'excellent',
  [ConnectionQuality.Good]: 'good',
  [ConnectionQuality.Poor]: 'poor',
  [ConnectionQuality.Lost]: 'lost',
};

class VoiceEngine {
  private room: Room | null = null;
  private ctx: AudioContext | null = null;
  private micStream: MediaStream | null = null;
  private micSource: MediaStreamAudioSourceNode | null = null;
  private inputGain: GainNode | null = null;
  private gate: GainNode | null = null;
  private dest: MediaStreamAudioDestinationNode | null = null;
  private stopMeter: (() => void) | null = null;
  private micPub: LocalTrackPublication | null = null;
  private vad = new VoiceActivityDetector(-50, true);
  private levelListeners = new Set<LevelListener>();
  private statsTimer: number | null = null;
  private sampler = new StatsSampler();
  private pttReleaseTimer: number | null = null;
  private intentionalLeave = false;
  private rejoinAttempts = 0;
  private audioSink: HTMLDivElement | null = null;
  private lastSpeakingSent = false;
  private joinSeq = 0;
  private mutedByBlur = false;

  constructor() {
    settingsStore.subscribe(() => this.onSettingsChanged(settingsStore.get()));
    gateway.on('voice:move', (d: { channelId: string }) => void this.join(d.channelId));
    gateway.on('voice:disconnect', () => {
      toast('Вы были отключены от голосового канала', 'info');
      void this.disconnect(false);
    });
    gateway.on('voice:state', (vs: { userId: string; serverMute: boolean; serverDeaf: boolean }) => {
      if (vs.userId !== getState().me?.id || !this.room) return;
      const s = voiceStore.get();
      if (s.serverMute !== vs.serverMute || s.serverDeaf !== vs.serverDeaf) {
        voiceStore.set({ serverMute: vs.serverMute, serverDeaf: vs.serverDeaf });
        if (vs.serverMute) toast('Модератор отключил вам микрофон на сервере');
        this.applyGate();
        this.applyVolumes();
      }
    });
    // After a gateway reconnect the server rebuilds presence from scratch: re-announce our voice state.
    gateway.on('ready', () => {
      if (this.room && voiceStore.get().channelId) this.announce();
    });
    window.addEventListener('blur', () => this.onWindowBlur());
    window.addEventListener('focus', () => this.onWindowFocus());
    window.addEventListener('beforeunload', () => {
      if (this.room) void this.room.disconnect();
    });
  }

  // ─────────────── public API ───────────────

  onLevel(fn: LevelListener): () => void {
    this.levelListeners.add(fn);
    return () => this.levelListeners.delete(fn);
  }

  get currentRoom(): Room | null {
    return this.room;
  }

  async join(channelId: string): Promise<void> {
    const seq = ++this.joinSeq;
    if (this.room) await this.disconnect(false, true);
    const ch = getState().channels[channelId];
    const prev = voiceStore.get();
    voiceStore.set({ ...initial, selfMute: prev.selfMute, selfDeaf: prev.selfDeaf, status: 'connecting', channelId, serverId: ch?.serverId ?? null, isDm: ch?.type === 'dm', version: prev.version + 1 });
    this.intentionalLeave = false;
    try {
      const grant = await api.post<{ token: string; url: string; serverMute: boolean; serverDeaf: boolean }>(`/voice/${channelId}/token`);
      if (seq !== this.joinSeq) return;
      await this.ensureAudioContext();
      const settings = settingsStore.get();
      const room = new Room({
        adaptiveStream: true,
        dynacast: true,
        webAudioMix: true,
        disconnectOnPageLeave: true,
        audioOutput: settings.outputDeviceId !== 'default' ? { deviceId: settings.outputDeviceId } : undefined,
        videoCaptureDefaults: { resolution: VideoPresets.h720.resolution },
        publishDefaults: {
          dtx: true,
          red: true,
          simulcast: true,
          videoSimulcastLayers: [VideoPresets.h180, VideoPresets.h360],
          screenShareEncoding: ScreenSharePresets.h1080fps30.encoding,
        },
      });
      this.room = room;
      this.wireRoom(room);
      await room.connect(resolveUrl(grant.url), grant.token, { autoSubscribe: false });
      if (seq !== this.joinSeq) {
        await room.disconnect();
        return;
      }
      voiceStore.set({ status: 'connected', joinedAt: Date.now(), serverMute: grant.serverMute, serverDeaf: grant.serverDeaf });
      log.info('voice connected', { room: room.name });
      for (const p of room.remoteParticipants.values()) this.onParticipant(p);
      await this.startMicrophone();
      this.announce();
      this.startStats();
      this.refreshParticipants();
      joinSound();
      this.rejoinAttempts = 0;
    } catch (err) {
      if (seq !== this.joinSeq) return;
      log.warn('voice join failed', { err: String(err) });
      await this.teardown();
      voiceStore.set({ ...initial, selfMute: voiceStore.get().selfMute, selfDeaf: voiceStore.get().selfDeaf });
      toast(errorMessage(err, 'Не удалось подключиться к голосовому каналу'), 'error');
    }
  }

  async disconnect(playSound = true, switching = false): Promise<void> {
    const s = voiceStore.get();
    this.intentionalLeave = true;
    if (!switching) this.joinSeq++;
    if (s.isDm && s.channelId && s.joinedAt) {
      gateway.send('call:end', { channelId: s.channelId, durationSec: (Date.now() - s.joinedAt) / 1000 });
    }
    if (s.channelId) gateway.send('voice:state', { channelId: null });
    await this.teardown();
    if (!switching) voiceStore.set({ ...initial, selfMute: s.selfMute, selfDeaf: s.selfDeaf, version: s.version + 1 });
    if (playSound && s.status !== 'idle') leaveSound();
  }

  /** Works before joining too: the choice is applied when a call starts. */
  toggleMute(): void {
    const s = voiceStore.get();
    // Unmuting while deafened also undeafens (same as Discord).
    if (s.selfMute && s.selfDeaf) {
      voiceStore.set({ selfDeaf: false });
      this.applyVolumes();
    }
    voiceStore.set({ selfMute: !s.selfMute });
    (s.selfMute ? unmuteSound : muteSound)();
    this.applyGate();
    this.announce();
  }

  toggleDeafen(): void {
    const s = voiceStore.get();
    const deaf = !s.selfDeaf;
    voiceStore.set({ selfDeaf: deaf, selfMute: deaf ? true : false });
    (deaf ? muteSound : unmuteSound)();
    this.applyGate();
    this.applyVolumes();
    this.announce();
  }

  /** Push-to-talk key state. */
  setPtt(held: boolean): void {
    if (settingsStore.get().inputMode !== 'ptt') return;
    if (this.pttReleaseTimer) {
      clearTimeout(this.pttReleaseTimer);
      this.pttReleaseTimer = null;
    }
    if (held) {
      voiceStore.set({ pttHeld: true });
      this.applyGate();
    } else {
      // Short release delay so the last syllable isn't clipped.
      this.pttReleaseTimer = window.setTimeout(() => {
        voiceStore.set({ pttHeld: false });
        this.applyGate();
      }, settingsStore.get().pttReleaseDelayMs);
    }
  }

  async setCamera(on: boolean): Promise<void> {
    if (!this.room) return;
    try {
      const deviceId = settingsStore.get().videoDeviceId;
      await this.room.localParticipant.setCameraEnabled(on, on && deviceId !== 'default' ? { deviceId } : undefined);
      voiceStore.set({ camera: on });
      this.bump();
      this.announce();
    } catch (err) {
      toast(mediaErrorMessage(err, 'camera'), 'error');
      voiceStore.set({ camera: false });
    }
  }

  /** Cycles through cameras, or flips front/back on phones with a single reported device. */
  async switchCamera(): Promise<void> {
    if (!this.room || !voiceStore.get().camera) return;
    const cams = (await navigator.mediaDevices.enumerateDevices()).filter((d) => d.kind === 'videoinput');
    const pub = this.room.localParticipant.getTrackPublication(Track.Source.Camera);
    const current = pub?.track?.mediaStreamTrack.getSettings();
    try {
      if (cams.length > 1) {
        const idx = cams.findIndex((c) => c.deviceId === current?.deviceId);
        const next = cams[(idx + 1) % cams.length]!;
        await this.room.switchActiveDevice('videoinput', next.deviceId);
        settingsStore.set({ videoDeviceId: next.deviceId });
      } else if (pub?.track && 'restartTrack' in pub.track) {
        const facingMode = current?.facingMode === 'environment' ? 'user' : 'environment';
        await (pub.track as unknown as { restartTrack(o: MediaTrackConstraints): Promise<void> }).restartTrack({ facingMode });
      } else {
        toast('Другая камера не найдена');
      }
      this.bump();
    } catch (err) {
      toast(mediaErrorMessage(err, 'camera'), 'error');
    }
  }

  async startScreenShare(): Promise<void> {
    if (!this.room) return;
    if (!navigator.mediaDevices || !('getDisplayMedia' in navigator.mediaDevices)) {
      toast('Ваш браузер не поддерживает демонстрацию экрана', 'error');
      return;
    }
    const audioDevice = settingsStore.get().streamAudioDeviceId;
    // A separate audio source (BlackHole on macOS, "Monitor of …" on Linux, a capture card…) replaces the
    // browser's own capture, so everyone hears the whole system sound even where browsers can't capture it.
    const useDevice = audioDevice !== 'auto';
    try {
      await this.room.localParticipant.setScreenShareEnabled(
        true,
        {
          audio: useDevice ? false : { echoCancellation: false, noiseSuppression: false, autoGainControl: false, channelCount: 2 },
          systemAudio: 'include',
          surfaceSwitching: 'include',
          selfBrowserSurface: 'exclude',
          suppressLocalAudioPlayback: false,
          resolution: ScreenSharePresets.h1080fps30.resolution,
          contentHint: 'detail',
        },
        STREAM_AUDIO_PUBLISH,
      );
      let hasAudio = !!this.room.localParticipant.getTrackPublication(Track.Source.ScreenShareAudio)?.track;
      if (useDevice) hasAudio = await this.publishStreamAudioDevice(audioDevice);
      voiceStore.set({ screen: true, screenAudio: hasAudio });
      if (!hasAudio && !useDevice) {
        // Chrome/Edge capture system audio only for a whole screen on Windows/ChromeOS; on macOS and Linux only a tab has audio.
        const hint =
          IS_MAC || IS_LINUX
            ? ' На macOS и Linux браузер отдаёт звук только при показе вкладки. Чтобы все слышали весь звук компьютера, выберите источник звука демонстрации в Настройки → Голос и видео.'
            : ' Включите галочку «Поделиться системным звуком» / «звуком вкладки» в окне выбора.';
        toast(`Звук недоступен для этого источника или браузера (System audio is not available for this source/browser).${hint}`, 'info');
      }
      this.bump();
      this.announce();
    } catch (err) {
      const { name, message } = err as { name?: string; message?: string };
      // "Permission denied by system" = the OS blocked screen recording (macOS privacy settings), not a user cancel.
      const deniedBySystem = name === 'NotAllowedError' && /system/i.test(message ?? '');
      if (deniedBySystem || (name !== 'NotAllowedError' && name !== 'AbortError')) toast(mediaErrorMessage(err, 'screen'), 'error');
      voiceStore.set({ screen: false, screenAudio: null });
    }
  }

  private streamAudioStream: MediaStream | null = null;

  /** Publishes an audio input device as the stream's audio track (raw, stereo, music bitrate). */
  private async publishStreamAudioDevice(deviceId: string): Promise<boolean> {
    if (!this.room) return false;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { deviceId: { exact: deviceId }, echoCancellation: false, noiseSuppression: false, autoGainControl: false, channelCount: 2, sampleRate: 48000 },
      });
      const track = stream.getAudioTracks()[0];
      if (!track) return false;
      this.streamAudioStream = stream;
      await this.room.localParticipant.publishTrack(track, { ...STREAM_AUDIO_PUBLISH, source: Track.Source.ScreenShareAudio, name: 'stream-audio' });
      return true;
    } catch (err) {
      toast(`Не удалось взять звук для демонстрации с выбранного устройства. ${mediaErrorMessage(err, 'mic')}`, 'error');
      return false;
    }
  }

  private async stopStreamAudioDevice(): Promise<void> {
    const track = this.streamAudioStream?.getAudioTracks()[0];
    if (this.room && track) await this.room.localParticipant.unpublishTrack(track).catch(() => undefined);
    this.streamAudioStream?.getTracks().forEach((t) => t.stop());
    this.streamAudioStream = null;
  }

  async stopScreenShare(): Promise<void> {
    if (!this.room) return;
    await this.stopStreamAudioDevice();
    await this.room.localParticipant.setScreenShareEnabled(false).catch(() => undefined);
    voiceStore.set({ screen: false, screenAudio: null });
    this.bump();
    this.announce();
  }

  /** Re-opens the browser picker to choose another screen/window/tab. */
  async changeScreenSource(): Promise<void> {
    await this.stopScreenShare();
    await this.startScreenShare();
  }

  /** Subscribes/unsubscribes to someone's stream (video + its audio). */
  watchStream(identity: string, on: boolean): void {
    const p = this.room?.remoteParticipants.get(identity);
    if (!p) return;
    if (on) this.unwatched.delete(identity);
    else this.unwatched.add(identity);
    for (const pub of p.trackPublications.values()) {
      if (pub.source === Track.Source.ScreenShare || pub.source === Track.Source.ScreenShareAudio) pub.setSubscribed(on);
    }
    this.refreshParticipants();
  }

  getVideoTrack(identity: string, source: 'camera' | 'screen'): Track | null {
    if (!this.room) return null;
    const src = source === 'camera' ? Track.Source.Camera : Track.Source.ScreenShare;
    const p = identity === this.room.localParticipant.identity ? this.room.localParticipant : this.room.remoteParticipants.get(identity);
    const track = p?.getTrackPublication(src)?.track;
    return track ?? null;
  }

  /** Applies per-user volume (0..2, client-side only). */
  setUserVolume(userId: string, volume: number): void {
    const s = settingsStore.get();
    settingsStore.set({ userVolumes: { ...s.userVolumes, [userId]: volume } });
  }

  setUserMuted(userId: string, muted: boolean): void {
    const s = settingsStore.get();
    settingsStore.set({ userMuted: { ...s.userMuted, [userId]: muted } });
  }

  async startAudioPlayback(): Promise<void> {
    await this.room?.startAudio();
    await this.ctx?.resume();
    voiceStore.set({ audioBlocked: false });
  }

  // ─────────────── microphone pipeline ───────────────

  private async ensureAudioContext(): Promise<AudioContext> {
    if (!this.ctx || this.ctx.state === 'closed') this.ctx = new AudioContext({ latencyHint: 'interactive' });
    if (this.ctx.state === 'suspended') await this.ctx.resume();
    return this.ctx;
  }

  private micConstraints(s: Settings): MediaTrackConstraints {
    return {
      deviceId: s.inputDeviceId !== 'default' ? { exact: s.inputDeviceId } : undefined,
      echoCancellation: s.echoCancellation,
      noiseSuppression: s.noiseSuppression,
      autoGainControl: s.autoGainControl,
      channelCount: 1,
      sampleRate: 48000,
    };
  }

  private async acquireMic(): Promise<void> {
    const s = settingsStore.get();
    const ctx = await this.ensureAudioContext();
    let stream: MediaStream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({ audio: this.micConstraints(s) });
    } catch (err) {
      if ((err as { name?: string }).name === 'OverconstrainedError' && s.inputDeviceId !== 'default') {
        // Saved device was unplugged: fall back to the system default.
        settingsStore.set({ inputDeviceId: 'default' });
        stream = await navigator.mediaDevices.getUserMedia({ audio: this.micConstraints(settingsStore.get()) });
      } else throw err;
    }
    this.stopMeter?.();
    this.micSource?.disconnect();
    this.micStream?.getTracks().forEach((t) => t.stop());
    this.micStream = stream;
    stream.getAudioTracks()[0]?.addEventListener('ended', () => {
      toast('Микрофон отключён', 'error');
      void this.acquireMic().catch(() => undefined);
    });
    this.micSource = ctx.createMediaStreamSource(stream);
    this.inputGain ??= ctx.createGain();
    this.gate ??= ctx.createGain();
    this.dest ??= ctx.createMediaStreamDestination();
    this.inputGain.gain.value = s.inputVolume;
    this.micSource.connect(this.inputGain);
    this.inputGain.connect(this.gate);
    this.gate.connect(this.dest);
    this.stopMeter = await createMeter(ctx, this.inputGain, ({ rmsDb }) => this.onLevelReading(rmsDb));
  }

  private async startMicrophone(): Promise<void> {
    if (!this.room) return;
    try {
      await this.acquireMic();
    } catch (err) {
      toast(mediaErrorMessage(err, 'mic'), 'error');
      voiceStore.set({ selfMute: true });
      return;
    }
    const track = this.dest!.stream.getAudioTracks()[0]!;
    this.applyGate();
    if (voiceStore.get().serverMute || voiceStore.get().serverDeaf) return; // SFU would reject the publication
    try {
      this.micPub = await this.room.localParticipant.publishTrack(track, { source: Track.Source.Microphone, name: 'microphone', dtx: true, red: true });
      if (voiceStore.get().selfMute) await this.micPub.mute();
    } catch (err) {
      log.warn('mic publish failed', { err: String(err) });
      toast('Не удалось передать звук микрофона', 'error');
    }
  }

  private onLevelReading(db: number): void {
    const s = settingsStore.get();
    this.vad.thresholdDb = s.vadThresholdDb;
    this.vad.auto = s.vadAuto;
    const vadOpen = this.vad.update(db);
    for (const l of this.levelListeners) l(db, this.vad.effectiveThreshold);
    const v = voiceStore.get();
    const gateOpen = this.computeGate();
    if (gateOpen !== v.gateOpen && s.inputMode === 'vad') this.applyGate();
    // Speaking = gate open AND real signal above the threshold.
    const speaking = gateOpen && (s.inputMode === 'vad' ? vadOpen : db > this.vad.effectiveThreshold);
    if (speaking !== v.localSpeaking) {
      voiceStore.set({ localSpeaking: speaking });
      this.refreshParticipants();
      if (speaking !== this.lastSpeakingSent) {
        this.lastSpeakingSent = speaking;
        gateway.send('voice:speaking', { speaking });
      }
    }
  }

  private computeGate(): boolean {
    const v = voiceStore.get();
    const s = settingsStore.get();
    if (v.selfMute || v.selfDeaf || v.serverMute || v.serverDeaf || this.mutedByBlur) return false;
    return s.inputMode === 'ptt' ? v.pttHeld : this.vad.isOpen;
  }

  private applyGate(): void {
    const open = this.computeGate();
    if (this.gate && this.ctx) {
      // 10 ms ramps avoid clicks when the gate toggles.
      this.gate.gain.setTargetAtTime(open ? 1 : 0, this.ctx.currentTime, 0.01);
    }
    const v = voiceStore.get();
    if (v.gateOpen !== open) voiceStore.set({ gateOpen: open });
    const shouldMute = v.selfMute || v.selfDeaf;
    if (this.micPub && this.micPub.isMuted !== shouldMute) void (shouldMute ? this.micPub.mute() : this.micPub.unmute());
  }

  private onWindowBlur(): void {
    // A key-up that happens while another window has focus is never delivered to us.
    if (voiceStore.get().pttHeld) this.setPtt(false);
    if (settingsStore.get().muteOnBlur && this.room) {
      this.mutedByBlur = true;
      this.applyGate();
    }
  }

  private onWindowFocus(): void {
    if (this.mutedByBlur) {
      this.mutedByBlur = false;
      this.applyGate();
    }
  }

  private prevSettings = settingsStore.get();
  private onSettingsChanged(s: Settings): void {
    const p = this.prevSettings;
    this.prevSettings = s;
    if (this.inputGain) this.inputGain.gain.value = s.inputVolume;
    if (!this.room) return;
    if (p.inputDeviceId !== s.inputDeviceId || p.noiseSuppression !== s.noiseSuppression || p.echoCancellation !== s.echoCancellation || p.autoGainControl !== s.autoGainControl) {
      // The published track comes from the WebAudio graph, so swapping the source needs no renegotiation.
      void this.acquireMic().catch((err) => toast(mediaErrorMessage(err, 'mic'), 'error'));
    }
    if (p.outputDeviceId !== s.outputDeviceId) void this.applyOutputDevice(s.outputDeviceId);
    if (p.videoDeviceId !== s.videoDeviceId && voiceStore.get().camera && s.videoDeviceId !== 'default') {
      void this.room.switchActiveDevice('videoinput', s.videoDeviceId);
    }
    if (p.inputMode !== s.inputMode) {
      voiceStore.set({ pttHeld: false });
      this.applyGate();
    }
    if (p.userVolumes !== s.userVolumes || p.userMuted !== s.userMuted || p.outputVolume !== s.outputVolume) this.applyVolumes();
  }

  private async applyOutputDevice(deviceId: string): Promise<void> {
    if (!this.room) return;
    try {
      await this.room.switchActiveDevice('audiooutput', deviceId);
    } catch {
      toast('Браузер не поддерживает выбор устройства вывода', 'error');
    }
  }

  private applyVolumes(): void {
    if (!this.room) return;
    const s = settingsStore.get();
    const deaf = voiceStore.get().selfDeaf || voiceStore.get().serverDeaf;
    for (const p of this.room.remoteParticipants.values()) {
      const muted = s.userMuted[p.identity];
      const base = (s.userVolumes[p.identity] ?? 1) * s.outputVolume;
      const v = deaf || muted ? 0 : base;
      p.setVolume(v, Track.Source.Microphone);
      p.setVolume(deaf ? 0 : (s.userVolumes[`stream:${p.identity}`] ?? 1) * s.outputVolume, Track.Source.ScreenShareAudio);
    }
  }

  // ─────────────── room events ───────────────

  private wireRoom(room: Room): void {
    room
      .on(RoomEvent.ParticipantConnected, (p) => {
        this.onParticipant(p);
        joinSound();
        this.refreshParticipants();
      })
      .on(RoomEvent.ParticipantDisconnected, () => {
        leaveSound();
        this.refreshParticipants();
        this.bump();
      })
      .on(RoomEvent.TrackPublished, (pub, p) => {
        this.autoSubscribe(pub, p);
        this.refreshParticipants();
      })
      .on(RoomEvent.TrackUnpublished, () => {
        this.refreshParticipants();
        this.bump();
      })
      .on(RoomEvent.TrackSubscribed, (track, _pub, p) => this.onTrackSubscribed(track, p))
      .on(RoomEvent.TrackUnsubscribed, (track) => {
        track.detach().forEach((el) => el.remove());
        this.refreshParticipants();
        this.bump();
      })
      .on(RoomEvent.TrackMuted, () => this.refreshParticipants())
      .on(RoomEvent.TrackUnmuted, () => this.refreshParticipants())
      .on(RoomEvent.ActiveSpeakersChanged, () => this.refreshParticipants())
      .on(RoomEvent.ConnectionQualityChanged, () => this.refreshParticipants())
      .on(RoomEvent.LocalTrackUnpublished, (pub) => {
        // Covers the browser's own "Stop sharing" button.
        if (pub.source === Track.Source.ScreenShare) {
          void this.stopStreamAudioDevice();
          voiceStore.set({ screen: false, screenAudio: null });
          this.announce();
        }
        if (pub.source === Track.Source.Camera) {
          voiceStore.set({ camera: false });
          this.announce();
        }
        this.bump();
      })
      .on(RoomEvent.LocalTrackPublished, () => this.bump())
      .on(RoomEvent.AudioPlaybackStatusChanged, () => voiceStore.set({ audioBlocked: !room.canPlaybackAudio }))
      .on(RoomEvent.MediaDevicesError, (err) => toast(mediaErrorMessage(err, 'mic'), 'error'))
      .on(RoomEvent.SignalReconnecting, () => log.info('webrtc signaling: reconnecting'))
      .on(RoomEvent.Reconnecting, () => {
        log.info('webrtc connection: reconnecting (ICE restart)');
        voiceStore.set({ status: 'reconnecting' });
      })
      .on(RoomEvent.Reconnected, () => {
        log.info('webrtc connection: reconnected');
        voiceStore.set({ status: 'connected' });
        this.sampler.reset();
        this.announce();
      })
      .on(RoomEvent.ConnectionStateChanged, (state) => log.info('webrtc connection state', { state }))
      .on(RoomEvent.Disconnected, (reason) => void this.onDisconnected(reason));
  }

  private onParticipant(p: RemoteParticipant): void {
    for (const pub of p.trackPublications.values()) this.autoSubscribe(pub, p);
  }

  /**
   * Mic and camera are always subscribed. Streams (screen video + its audio) too when "auto-watch" is on
   * (default, so everyone hears the demo); otherwise only after "Смотреть трансляцию".
   */
  private autoSubscribe(pub: RemoteTrackPublication, p: RemoteParticipant): void {
    if (pub.source === Track.Source.Microphone || pub.source === Track.Source.Camera) pub.setSubscribed(true);
    else if ((pub.source === Track.Source.ScreenShare || pub.source === Track.Source.ScreenShareAudio) && settingsStore.get().autoWatchStreams && !this.unwatched.has(p.identity)) {
      pub.setSubscribed(true);
    }
  }

  /** Streams the user explicitly stopped watching (not re-subscribed automatically). */
  private unwatched = new Set<string>();

  private onTrackSubscribed(track: RemoteTrack, p: RemoteParticipant): void {
    if (track.kind === Track.Kind.Audio) {
      this.audioSink ??= Object.assign(document.createElement('div'), { hidden: true });
      if (!this.audioSink.isConnected) document.body.appendChild(this.audioSink);
      const el = track.attach();
      this.audioSink.appendChild(el);
      this.applyVolumes();
      voiceStore.set({ audioBlocked: !this.room?.canPlaybackAudio });
    }
    void p;
    this.refreshParticipants();
    this.bump();
  }

  private async onDisconnected(reason?: DisconnectReason): Promise<void> {
    log.info('webrtc disconnected', { reason });
    if (this.intentionalLeave || !this.room) return;
    const channelId = voiceStore.get().channelId;
    const fatal = reason === DisconnectReason.PARTICIPANT_REMOVED || reason === DisconnectReason.ROOM_DELETED || reason === DisconnectReason.DUPLICATE_IDENTITY;
    if (fatal || !channelId) {
      if (reason === DisconnectReason.DUPLICATE_IDENTITY) toast('Вы подключились к голосу с другого устройства');
      await this.disconnect(false);
      return;
    }
    // Network recovery beyond LiveKit's own resume: rejoin with a fresh token, with backoff.
    voiceStore.set({ status: 'reconnecting' });
    await this.teardown(true);
    const delay = Math.min(15_000, 1000 * 2 ** this.rejoinAttempts++);
    log.info('voice: rejoining', { delay });
    setTimeout(() => {
      if (voiceStore.get().channelId === channelId && voiceStore.get().status === 'reconnecting') {
        const keep = voiceStore.get();
        void this.join(channelId).then(() => {
          if (keep.selfMute !== voiceStore.get().selfMute) this.toggleMute();
        });
      }
    }, delay);
  }

  private async teardown(keepState = false): Promise<void> {
    if (this.statsTimer) clearInterval(this.statsTimer);
    this.statsTimer = null;
    this.stopMeter?.();
    this.stopMeter = null;
    this.micStream?.getTracks().forEach((t) => t.stop());
    this.micStream = null;
    this.micSource?.disconnect();
    this.micSource = null;
    this.micPub = null;
    this.inputGain?.disconnect();
    this.gate?.disconnect();
    this.inputGain = null;
    this.gate = null;
    this.dest = null;
    const room = this.room;
    this.room = null;
    if (room) {
      room.removeAllListeners();
      await room.disconnect().catch(() => undefined);
    }
    this.audioSink?.replaceChildren();
    this.sampler.reset();
    if (this.lastSpeakingSent) {
      this.lastSpeakingSent = false;
      gateway.send('voice:speaking', { speaking: false });
    }
    if (!keepState) voiceStore.set({ participants: {}, stats: null });
  }

  /** Tells the gateway our channel + self state so others see mute/camera/stream icons. */
  private announce(): void {
    const v = voiceStore.get();
    if (!v.channelId) return;
    gateway.send('voice:state', { channelId: v.channelId, selfMute: v.selfMute, selfDeaf: v.selfDeaf, camera: v.camera, screen: v.screen });
  }

  private bump(): void {
    voiceStore.set((s) => ({ version: s.version + 1 }));
  }

  private refreshParticipants(): void {
    const room = this.room;
    if (!room) return;
    const views: Record<string, ParticipantView> = {};
    const add = (p: Participant, isLocal: boolean) => {
      let meta: { avatarUrl?: string | null } = {};
      try {
        meta = p.metadata ? JSON.parse(p.metadata) : {};
      } catch {
        /* ignore */
      }
      const mic = p.getTrackPublication(Track.Source.Microphone);
      const screen = p.getTrackPublication(Track.Source.ScreenShare);
      views[p.identity] = {
        identity: p.identity,
        name: p.name || p.identity,
        avatarUrl: meta.avatarUrl ?? null,
        isLocal,
        speaking: isLocal ? voiceStore.get().localSpeaking : p.isSpeaking,
        micMuted: isLocal ? voiceStore.get().selfMute : !mic || mic.isMuted,
        hasCamera: !!p.getTrackPublication(Track.Source.Camera) && !p.getTrackPublication(Track.Source.Camera)!.isMuted,
        hasScreen: !!screen,
        hasScreenAudio: !!p.getTrackPublication(Track.Source.ScreenShareAudio),
        watchingScreen: isLocal ? !!screen : !!(screen as RemoteTrackPublication | undefined)?.isSubscribed,
        quality: QUALITY[p.connectionQuality] ?? 'unknown',
      };
    };
    add(room.localParticipant, true);
    for (const p of room.remoteParticipants.values()) add(p, false);
    voiceStore.set({ participants: views });
  }

  private startStats(): void {
    if (this.statsTimer) clearInterval(this.statsTimer);
    const tick = async () => {
      const room = this.room;
      if (!room) return;
      const local = [...room.localParticipant.trackPublications.values()].map((p) => p.track).filter((t): t is NonNullable<typeof t> => !!t);
      const remote = [...room.remoteParticipants.values()].flatMap((p) => [...p.trackPublications.values()].map((pub) => pub.track)).filter((t): t is NonNullable<typeof t> => !!t);
      try {
        const [pub, sub] = await Promise.all([Promise.all(local.map((t) => t.getRTCStatsReport())), Promise.all(remote.map((t) => t.getRTCStatsReport()))]);
        const stats = this.sampler.sample(pub, sub);
        const prev = voiceStore.get().stats;
        if (prev?.iceState !== stats.iceState) log.info('webrtc ice state', { ice: stats.iceState, dtls: stats.dtlsState, transport: stats.transport });
        voiceStore.set({ stats });
      } catch (err) {
        log.debug('stats failed', { err: String(err) });
      }
    };
    void tick();
    this.statsTimer = window.setInterval(() => void tick(), 1500);
  }
}

/** The backend may return a path ("/livekit"); turn it into a ws(s) URL on the current host. */
function resolveUrl(url: string): string {
  if (/^wss?:\/\//.test(url)) return url;
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  return `${proto}://${location.host}${url.startsWith('/') ? url : `/${url}`}`;
}

export const voice = new VoiceEngine();

// Microphone test (settings page): same pipeline as a call, but played back locally and never sent.
export interface MicTest {
  stop(): void;
}

export async function startMicTest(opts: { loopback: boolean; onLevel: (db: number, thr: number) => void }): Promise<MicTest> {
  const s = settingsStore.get();
  const ctx = new AudioContext({ latencyHint: 'interactive' });
  const stream = await navigator.mediaDevices.getUserMedia({
    audio: {
      deviceId: s.inputDeviceId !== 'default' ? { exact: s.inputDeviceId } : undefined,
      echoCancellation: s.echoCancellation,
      noiseSuppression: s.noiseSuppression,
      autoGainControl: s.autoGainControl,
    },
  });
  const src = ctx.createMediaStreamSource(stream);
  const gain = ctx.createGain();
  gain.gain.value = s.inputVolume;
  src.connect(gain);
  const vad = new VoiceActivityDetector(s.vadThresholdDb, s.vadAuto);
  const stopMeter = await createMeter(ctx, gain, ({ rmsDb }) => {
    const st = settingsStore.get();
    vad.thresholdDb = st.vadThresholdDb;
    vad.auto = st.vadAuto;
    vad.update(rmsDb);
    opts.onLevel(rmsDb, vad.effectiveThreshold);
  });
  let audioEl: HTMLAudioElement | null = null;
  if (opts.loopback) {
    // Played through an <audio> element so the selected output device (setSinkId) is honoured.
    const out = ctx.createMediaStreamDestination();
    gain.connect(out);
    audioEl = new Audio();
    audioEl.srcObject = out.stream;
    if (s.outputDeviceId !== 'default' && 'setSinkId' in audioEl) {
      await (audioEl as HTMLAudioElement & { setSinkId(id: string): Promise<void> }).setSinkId(s.outputDeviceId).catch(() => undefined);
    }
    await audioEl.play().catch(() => undefined);
  }
  return {
    stop() {
      stopMeter();
      audioEl?.pause();
      stream.getTracks().forEach((t) => t.stop());
      void ctx.close();
    },
  };
}
