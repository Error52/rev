import 'dotenv/config';
import bcrypt from 'bcryptjs';
import { PrismaClient } from '@prisma/client';
const prisma=new PrismaClient();
async function main(){
 const hash=await bcrypt.hash('Password123!',12);
 const a=await prisma.user.upsert({where:{email:'demo@example.com'},update:{},create:{email:'demo@example.com',passwordHash:hash,username:'demo',displayName:'Demo User',presence:'ONLINE'}});
 const b=await prisma.user.upsert({where:{email:'alice@example.com'},update:{},create:{email:'alice@example.com',passwordHash:hash,username:'alice',displayName:'Alice'}});
 let s=await prisma.server.findFirst({where:{name:'Demo Server'}});
 if(!s)s=await prisma.server.create({data:{name:'Demo Server',ownerId:a.id,roles:{create:[{name:'@everyone',permissions:[]},{name:'Admin',permissions:['ADMINISTRATOR']},{name:'Moderator',permissions:['MANAGE_MESSAGES','KICK_MEMBERS','BAN_MEMBERS','TIMEOUT_MEMBERS','VIEW_AUDIT_LOG']}]},members:{create:[{userId:a.id,role:'OWNER'},{userId:b.id,role:'MEMBER'}]},channels:{create:[{name:'general',type:'TEXT'},{name:'memes',type:'TEXT'},{name:'General',type:'VOICE'}]}}});
 const c=await prisma.channel.findFirst({where:{serverId:s.id,type:'TEXT',name:'general'}});
 if(c && !(await prisma.message.count({where:{channelId:c.id}}))) await prisma.message.createMany({data:[{channelId:c.id,authorId:a.id,content:'Добро пожаловать в Mini Discord!'},{channelId:c.id,authorId:b.id,content:'Проверка realtime-чата, реакций и threads.'}]});
 console.log('seed complete', {demo:'demo@example.com / Password123!', server:s.id});
}
main().finally(()=>prisma.$disconnect());
