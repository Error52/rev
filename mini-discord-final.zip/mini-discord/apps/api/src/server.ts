io.on('connection',socket=>{
  const userId=(socket as any).userId;
  socket.join(`user:${userId}`);
  socket.on('channel:join',({channelId})=>socket.join(`channel:${channelId}`));
  socket.on('dm:join',({conversationId})=>socket.join(`dm:${conversationId}`));
  socket.on('message:send',async({channelId,conversationId,content,gifUrl,parentId,attachments})=>{
    if(!content?.trim()&&!gifUrl&&!(attachments?.length)) return;
    const member=conversationId?await prisma.conversationMember.findUnique({where:{conversationId_userId:{conversationId,userId}}}):null;
    if(conversationId&&!member) return;
    const m=await prisma.message.create({data:{channelId:channelId||undefined,conversationId:conversationId||undefined,parentId:parentId||undefined,authorId:userId,content:content?.trim()??'',gifUrl,attachments:attachments?.length?{create:attachments.map((a:any)=>({uploaderId:userId,...a}))}:undefined},include:messageInclude()});
    const payload={...m,author:publicUser(m.author)};
    if(channelId){
      io.to(`channel:${channelId}`).emit('message:new',payload);
      const ch=await prisma.channel.findUnique({where:{id:channelId}});
      if(ch){const members=await prisma.serverMember.findMany({where:{serverId:ch.serverId},select:{userId:true}});for(const x of members) if(x.userId!==userId) await notify(x.userId,NotificationType.MESSAGE,'New message',m.content.slice(0,100),`/server/${ch.serverId}/channel/${channelId}`);}
    } else if(conversationId){
      io.to(`dm:${conversationId}`).emit('message:new',payload);
      const cm=await prisma.conversationMember.findMany({where:{conversationId}});
      for(const x of cm) if(x.userId!==userId) await notify(x.userId,NotificationType.MESSAGE,'New direct message',m.content.slice(0,100),`/dm/${conversationId}`);
    }
  });
  socket.on('typing',({channelId,conversationId,typing})=>socket.to(channelId?`channel:${channelId}`:`dm:${conversationId}`).emit('typing',{userId,typing}));
  socket.on('presence',async({presence})=>{await prisma.user.update({where:{id:userId},data:{presence}});io.emit('presence',{userId,presence})});
  socket.on('disconnect',async()=>{await prisma.user.update({where:{id:userId},data:{presence:'OFFLINE'}}).catch(()=>{});io.emit('presence',{userId,presence:'OFFLINE'});});
});
