# Mini Discord — full realtime communication app

## Included

- Registration/login with bcrypt + JWT
- Servers, text/voice channels
- Direct messages and friends
- Realtime Socket.IO messaging
- GIF search through GIPHY or Tenor
- S3-compatible uploads with presigned URLs (MinIO in local compose)
- Attachments, reactions, replies and threads
- Server roles + permissions + moderation endpoint
- Notifications + unread state
- Invite links with expiry/max-use/revocation
- WebRTC through LiveKit
- coturn for NAT traversal
- Push-to-talk, device selection, screen share and system-audio request
- WebRTC connection stats
- Per-user volume
- Profile themes and badges
- Audit log
- Production Caddy HTTPS/WSS setup

## Local

```bash
cp .env.example .env
docker compose up --build
```

Open `http://localhost`.

MinIO console: `http://localhost:9001` (`minio` / `miniosecret`).

Seed demo data:

```bash
docker compose exec api npm run seed
```

Demo account: `demo@example.com` / `Password123!`

## GIF

Set `GIPHY_API_KEY` or `TENOR_API_KEY` in `.env`. The API keeps the provider key on the backend.

## Production HTTPS/WSS

Copy `.env.prod.example` to `.env.prod`, replace all secrets/domains/IPs and place TURN certificates in `infra/coturn/fullchain.pem` and `infra/coturn/privkey.pem`.

Then:

```bash
docker compose --env-file .env.prod -f docker-compose.prod.yml up -d --build
```

Caddy obtains HTTPS certificates automatically for the application, RTC and S3 hostnames. TURN certificates are mounted separately because coturn needs the certificate files directly.

Open on the firewall:

- TCP 80/443
- TCP/UDP 3478
- TCP 5349
- UDP 49160-49200
- LiveKit UDP 50000-60000

For production, use strong secrets and a real S3/MinIO deployment. Do not expose the MinIO admin console publicly.
